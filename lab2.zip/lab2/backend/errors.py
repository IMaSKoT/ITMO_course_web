class DormitoryDataError(Exception):
    pass
